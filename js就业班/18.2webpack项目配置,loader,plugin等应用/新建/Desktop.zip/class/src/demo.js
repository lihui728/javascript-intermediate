(function (){
    console.log('demo.js')
}())