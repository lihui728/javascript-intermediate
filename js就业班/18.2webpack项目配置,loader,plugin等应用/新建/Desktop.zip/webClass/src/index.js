function aa(){
    console.log('aa');
    console.log('aa');
    console.log('aa');
    console.log('aa');
    console.log('aa');
    console.log('aa');
}
aa();
//css 也是模块，也要require引进来
//require('./css/index.css');
require('./css/index.less');
var demo = require('./demo.js');
var a = demo();
console.log(a.a);